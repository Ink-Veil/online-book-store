package com.bookstore.controller;

import com.bookstore.model.Book;
import com.bookstore.model.Category;
import com.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.data.domain.Page;
import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/featured")
    public List<Book> getFeaturedBooks() {
        return bookService.getFeaturedBooks(5);
    }

    @GetMapping
    public Page<Book> getAllBooks(@RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "6") int size) {
        return bookService.getAllBooks(page, size);
    }

    @GetMapping("/search")
    public Page<Book> searchBooks(@RequestParam String query,
                                  @RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "6") int size) {
        return bookService.searchBooksByTitle(query, page, size);
    }

    @GetMapping("/category")
    public Page<Book> searchByCategory(@RequestParam String name,
                                       @RequestParam(defaultValue = "0") int page,
                                       @RequestParam(defaultValue = "6") int size) {
        return bookService.searchBooksByCategory(name, page, size);
    }

    @GetMapping("/categories")
    public List<Category> getAllCategories() {
        return bookService.getAllCategories();
    }
}
