package com.bookstore.service;

import com.bookstore.model.Book;
import com.bookstore.model.Category;
import com.bookstore.repository.BookRepository;
import com.bookstore.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepo;

    @Autowired
    private CategoryRepository categoryRepo;

    public Page<Book> getAllBooks(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("title").ascending());
        return bookRepo.findAll(pageable);
    }

    public List<Book> getFeaturedBooks(int count) {
        return bookRepo.findAll(PageRequest.of(0, count)).getContent();
    }

    public Page<Book> searchBooksByTitle(String title, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return bookRepo.findByTitleContainingIgnoreCase(title, pageable);
    }

    public Page<Book> searchBooksByCategory(String categoryName, int page, int size) {
        Category category = categoryRepo.findByNameIgnoreCase(categoryName);
        if (category != null) {
            return bookRepo.findByCategory(category, PageRequest.of(page, size));
        }
        return Page.empty();
    }

    public List<Category> getAllCategories() {
        return categoryRepo.findAll();
    }
}
