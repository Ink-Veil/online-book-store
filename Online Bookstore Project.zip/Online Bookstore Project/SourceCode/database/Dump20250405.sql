-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bookstore_db
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (1,'Atomic Habits','James Clear','Self-improvement book','https://covers.openlibrary.org/b/id/9254151-L.jpg',19.99,10,2),(2,'Pride and Prejudice','Jane Austen','Classic romance novel','https://covers.openlibrary.org/b/id/10958366-L.jpg',14.99,5,3),(3,'1984','George Orwell','Dystopian fiction','https://covers.openlibrary.org/b/id/11103214-L.jpg',12.99,7,1),(4,'The Hobbit','J.R.R. Tolkien','Fantasy novel','https://covers.openlibrary.org/b/id/10564958-L.jpg',17.5,10,1),(5,'Sapiens','Yuval Noah Harari','Human history from the Stone Age to today','https://covers.openlibrary.org/b/id/12318644-L.jpg',22,6,2),(6,'Jane Eyre','Charlotte Brontë','Classic novel about love and self-worth','https://covers.openlibrary.org/b/id/11147054-L.jpg',18.75,4,3),(19,'The Lean Startup','Eric Ries','Startup principles','https://covers.openlibrary.org/b/id/10025029-L.jpg',20,6,5),(20,'The Da Vinci Code','Dan Brown','Mystery thriller novel','https://covers.openlibrary.org/b/id/9254032-L.jpg',15.5,10,8),(21,'Steve Jobs','Walter Isaacson','Biography of Steve Jobs','https://covers.openlibrary.org/b/id/10557655-L.jpg',23,5,4),(22,'The 7 Habits of Highly Effective People','Stephen R. Covey','Personal development','https://covers.openlibrary.org/b/id/12223845-L.jpg',18.99,12,5),(23,'The Name of the Wind','Patrick Rothfuss','Epic fantasy novel','https://covers.openlibrary.org/b/id/10015399-L.jpg',16.8,8,6),(24,'Clean Code','Robert C. Martin','Software craftsmanship','https://covers.openlibrary.org/b/id/6225296-L.jpg',29.99,3,7);
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Fiction'),(2,'Science'),(3,'Romance'),(4,'Biography'),(5,'Business'),(6,'Fantasy'),(7,'Technology'),(8,'Mystery');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'bookstore_db'
--

--
-- Dumping routines for database 'bookstore_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-05 17:55:43
