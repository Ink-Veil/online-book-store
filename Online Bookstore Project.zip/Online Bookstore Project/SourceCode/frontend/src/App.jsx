import { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import HomePage from "./pages/HomePage";
import AllBooksPage from "./pages/AllBooksPage";

function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? "dark" : ""}>
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <Router>
          {/* 🌙 Navbar */}
          <nav className="bg-white dark:bg-gray-800 shadow p-4 flex justify-between items-center">
            <h1 className="text-xl font-bold">📚 Once Upon a Dime's Bookstore</h1>
            <div className="flex items-center gap-4">
              <Link to="/" className="hover:underline">Home</Link>
              <Link to="/books" className="hover:underline">All Books</Link>
              {/* 🌗 Toggle Button */}
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="ml-4 px-3 py-1 bg-gray-200 dark:bg-gray-700 rounded text-sm"
              >
                {darkMode ? "☀️ Light Mode" : "🌙 Dark Mode"}
              </button>
            </div>
          </nav>

          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/books" element={<AllBooksPage />} />
          </Routes>
        </Router>
      </div>
    </div>
  );
}

export default App;
