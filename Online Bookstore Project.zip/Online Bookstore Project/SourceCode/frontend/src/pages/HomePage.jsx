import { useEffect, useState } from "react";
import API from "../api";
import BookCard from "../components/BookCard";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";


export default function HomePage() {
  const [books, setBooks] = useState([]);
  const [moreBooks, setMoreBooks] = useState([]);

  useEffect(() => {
    API.get("/books/featured")
      .then(res => setBooks(res.data))
      .catch(err => console.error(err));

      API.get("/books?page=2&size=4")  // 👈 Fetch books from the next page
    .then(res => setMoreBooks(res.data.content))
    .catch(err => console.error(err));
  }, []);

  return (
    <div className="p-4">
      {/* 🌟 Hero Section */}
      <section
  className="relative bg-cover bg-center text-white rounded-xl shadow mb-10"
  style={{
    backgroundImage: `url('https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1400&q=80')`,
    height: "350px",
  }}
>
  <div className="absolute inset-0 bg-black bg-opacity-50 rounded-xl flex flex-col justify-center items-center text-center px-6">
    <h1 className="text-4xl font-bold mb-4">Welcome to Once Upon a Dime’s Online Bookstore 📚</h1>
    <p className="text-lg max-w-xl mb-6">Discover your next great read – from fiction to tech, all in one place.</p>
    <a
      href="/books"
      className="px-6 py-2 bg-blue-600 text-white font-semibold rounded hover:bg-blue-700 transition"
    >
      Browse All Books
    </a>
  </div>
</section>


      {/* Featured Books */}
<h2 className="text-2xl font-bold mb-4">Featured Books</h2>

<Slider
  dots={true}
  infinite={true}
  speed={500}
  slidesToShow={3}
  slidesToScroll={1}
  autoplay={true}
  autoplaySpeed={3000} // <-- 3 seconds
  arrows={true}        // <-- Enable arrows
  responsive={[
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 640,
      settings: {
        slidesToShow: 1,
      },
    },
  ]}
>
  {books.map((book) => (
    <div key={book.id} className="px-2">
      <BookCard book={book} />
    </div>
  ))}
</Slider>

<h2 className="text-2xl font-bold mt-10 mb-4">More Books You Might Like</h2>
<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
  {moreBooks.map(book => (
    <BookCard key={book.id} book={book} />
  ))}
</div>

    </div>
  );
}
