import { useEffect, useState } from "react";
import API from "../api";
import BookCard from "../components/BookCard";
import SearchBar from "../components/SearchBar";
import CategoryFilter from "../components/CategoryFilter";

export default function AllBooksPage() {
    const [books, setBooks] = useState([]);
    const [query, setQuery] = useState("");
    const [category, setCategory] = useState("");
    const [page, setPage] = useState(0);
    const [totalPages, setTotalPages] = useState(0);
  
    const fetchBooks = () => {
      const endpoint = query
        ? `/books/search?query=${query}&page=${page}`
        : category
        ? `/books/category?name=${category}&page=${page}`
        : `/books?page=${page}`;
  
      API.get(endpoint)
        .then(res => {
          setBooks(res.data.content);
          setTotalPages(res.data.totalPages);
        })
        .catch(err => console.error(err));
    };
  
    useEffect(() => {
      fetchBooks();
    }, [query, category, page]);
  
    return (
      <div className="p-4">
        <SearchBar onSearch={term => {
          setQuery(term);
          setPage(0);
        }} />
        
        <CategoryFilter onSelect={cat => {
          setCategory(cat);
          setPage(0);
        }} />
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
          {books.map(book => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
  
        <div className="flex justify-center mt-4 gap-4">
          <button onClick={() => setPage(p => Math.max(p - 1, 0))} disabled={page === 0}>
            Prev
          </button>
          <button onClick={() => setPage(p => p + 1)} disabled={page + 1 >= totalPages}>
            Next
          </button>
        </div>
      </div>
    );
  }
