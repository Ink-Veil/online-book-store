export default function BookCard({ book }) {
    return (
        
        <div className="bg-white dark:bg-gray-800 border rounded p-4 shadow text-gray-800 dark:text-gray-100">

        <img src={book.imageUrl} alt={book.title} className="h-40 w-full object-cover mb-2"/>
        <h2 className="font-semibold">{book.title}</h2>
        <p className="text-sm">{book.author}</p>
        <p className="text-sm text-gray-600">${book.price}</p>
      </div>
    );
  }
  