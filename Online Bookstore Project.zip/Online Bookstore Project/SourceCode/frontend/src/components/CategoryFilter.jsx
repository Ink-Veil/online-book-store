import { useEffect, useState } from "react";
import API from "../api";

export default function CategoryFilter({ onSelect }) {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    API.get("/books/categories")
      .then(res => {
        if (Array.isArray(res.data)) {
          setCategories(res.data);
        } else {
          setCategories([]);
        }
      })
      .catch(err => {
        console.error(err);
        setCategories([]); // in case of error, set it to empty
      });
  }, []);

  return (
    <div className="mb-2">
      <select onChange={(e) => onSelect(e.target.value)} className="bg-white dark:bg-gray-800 border rounded p-2 w-full shadow text-gray-800 dark:text-gray-100">
        <option value="">Filter by Category</option>
        {categories.map(cat => (
          <option key={cat.id} value={cat.name}>{cat.name}</option>
        ))}
      </select>
    </div>
  );
}
