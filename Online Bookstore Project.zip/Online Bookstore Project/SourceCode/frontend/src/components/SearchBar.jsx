import { useState } from "react";

export default function SearchBar({ onSearch }) {
  const [term, setTerm] = useState("");

  const handleSearch = () => onSearch(term);

  return (
    <div className="flex items-center gap-2 mb-2">
      <input
        className="bg-white dark:bg-gray-800 border rounded p-2 flex-grow shadow text-gray-800 dark:text-gray-100"

        placeholder="Search by title"
        value={term}
        onChange={(e) => setTerm(e.target.value)}
      />
      <button className="bg-blue-500 text-white px-4 py-2" onClick={handleSearch}>
        Search
      </button>
    </div>
  );
}
